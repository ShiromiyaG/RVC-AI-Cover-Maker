from .mix import mix_main
from .reverbpedalboard import reverbpedalboard_main
from .spectograma import process_spectrogram